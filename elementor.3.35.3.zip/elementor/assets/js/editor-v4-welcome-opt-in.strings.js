__( 'Say hello to a new experience!', 'elementor' );
__( 'You now have access to the beta of version 4, ready to use on production.', 'elementor' );
__( 'Try out Atomic Elements such as: Flexbox, Heading, Button & Paragraph.', 'elementor' );
__( 'Apply Variables and Classes site-wide for perfect consistency.', 'elementor' );
__( 'Customize any style element per screen size by switching between responsive views.', 'elementor' );
__( 'Need help getting started?', 'elementor' );
__( 'Learn more', 'elementor' );
__( 'Let\'s Go', 'elementor' );