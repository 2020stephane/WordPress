__( 'Clear', 'elementor' );
__( "Don't show this again", 'elementor' );
__( 'Got it introduction', 'elementor' );
__( 'Got it', 'elementor' );
__( 'Upgrade Now', 'elementor' );
__( 'Not now', 'elementor' );
__( 'Delete', 'elementor' );