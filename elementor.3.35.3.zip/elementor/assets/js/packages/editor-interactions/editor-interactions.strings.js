__( 'Interactions', 'elementor' );
__(
					"You've reached the limit of 5 interactions for this element. Please remove an interaction before creating a new one.",
					'elementor'
				);
__( 'Interactions', 'elementor' );
__( 'Preview', 'elementor' );
__( 'Play interaction', 'elementor' );
__( 'Trigger', 'elementor' );
__( 'Replay', 'elementor' );
__( 'Effect', 'elementor' );
__( 'Type', 'elementor' );
__( 'Direction', 'elementor' );
__( 'Duration', 'elementor' );
__( 'Delay', 'elementor' );
__( 'Relative To', 'elementor' );
__( 'Offset Top', 'elementor' );
__( 'Offset Bottom', 'elementor' );
__( 'Animate elements with Interactions', 'elementor' );
__(
					'Add entrance animations and effects triggered by user interactions such as page load or scroll.',
					'elementor'
				);
__( 'Create an interaction', 'elementor' );
__( 'Page load', 'elementor' );
__( 'Scroll into view', 'elementor' );
// translators: %s: time in milliseconds
__( '%s MS', 'elementor' );
__( 'No', 'elementor' );
__( 'Yes', 'elementor' );
__( 'Fade', 'elementor' );
__( 'Slide', 'elementor' );
__( 'Scale', 'elementor' );
__( 'In', 'elementor' );
__( 'In', 'elementor' );
__( 'Out', 'elementor' );
__( 'Out', 'elementor' );
__( 'From top', 'elementor' );
__( 'To top', 'elementor' );
__( 'From bottom', 'elementor' );
__( 'To bottom', 'elementor' );
__( 'From left', 'elementor' );
__( 'To left', 'elementor' );
__( 'From right', 'elementor' );
__( 'To right', 'elementor' );