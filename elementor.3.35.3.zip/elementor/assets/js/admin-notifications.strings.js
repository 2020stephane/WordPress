__( 'What\'s New', 'elementor' );
__( 'What\'s New', 'elementor' );
__( "What's New", 'elementor' );